import { useEffect, useState } from 'react'
import { api } from '../lib/api.js'
import { useAuth } from '../context/AuthContext.jsx'
import { useToast } from '../components/Toast.jsx'
import ProductCard from '../components/ProductCard.jsx'
import ConfirmModal from '../components/ConfirmModal.jsx'
import EmptyState from '../components/EmptyState.jsx'
import Spinner from '../components/Spinner.jsx'

export default function Home() {
  const { token, username, refreshMoney } = useAuth()
  const toast = useToast()
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [confirmProduct, setConfirmProduct] = useState(null)
  const [buying, setBuying] = useState(false)

  async function load() {
    setLoading(true)
    try {
      const data = await api.getProducts(token)
      setProducts(data)
    } catch (err) {
      // backend returns 404 when the table is empty — that's not a real error
      setProducts(err.status === 404 ? [] : products)
      if (err.status !== 404) toast.push(err.message, 'error')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  async function confirmBuy() {
    setBuying(true)
    try {
      await api.buyProduct(confirmProduct.id, token)
      toast.push(`تم شراء ${confirmProduct.product_name}`)
      setConfirmProduct(null)
      await Promise.all([load(), refreshMoney()])
    } catch (err) {
      toast.push(err.message, 'error')
    } finally {
      setBuying(false)
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center py-16 text-awning">
        <Spinner />
      </div>
    )
  }

  if (products.length === 0) {
    return <EmptyState title="الرف فاضي" hint="ما فيه منتجات معروضة حاليًا" />
  }

  return (
    <>
      <div className="grid grid-cols-2 gap-3">
        {products.map((p) => (
          <ProductCard
            key={p.id}
            product={p}
            isOwn={p.owner?.username === username}
            buying={buying && confirmProduct?.product_name === p.product_name}
            onBuy={() => setConfirmProduct(p)}
          />
        ))}
      </div>

      <ConfirmModal
        open={!!confirmProduct}
        title={`شراء ${confirmProduct?.product_name ?? ''}؟`}
        body={confirmProduct ? `بسعر ${confirmProduct.price.toLocaleString('en-US')} ر.س، بينخصم من رصيدك مباشرة.` : ''}
        confirmLabel="تأكيد الشراء"
        loading={buying}
        onConfirm={confirmBuy}
        onCancel={() => setConfirmProduct(null)}
      />
    </>
  )
}
