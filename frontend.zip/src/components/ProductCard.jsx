export default function ProductCard({ product, isOwn, onBuy, buying }) {
  const outOfStock = product.amount <= 0

  return (
    <div className="bg-card/70 border border-stone rounded-2xl overflow-hidden flex flex-col">
      <div className={`aspect-square bg-stone flex items-center justify-center ${outOfStock ? 'grayscale opacity-60' : ''}`}>
        {product.image_url ? (
          <img
            src={product.image_url}
            alt={product.product_name}
            className="w-full h-full object-cover"
            onError={(e) => { e.currentTarget.style.display = 'none' }}
          />
        ) : (
          <span className="text-3xl">٠</span>
        )}
      </div>

      <div className="p-3 flex flex-col gap-1.5 flex-1">
        <h3 className="font-display font-bold text-sm leading-snug line-clamp-1">
          {product.product_name}
        </h3>
        {product.description && (
          <p className="text-xs text-inkfaint line-clamp-2 flex-1">{product.description}</p>
        )}

        <div className="flex items-center justify-between mt-1.5">
          <span className="price-tag bg-mustard/15 text-mustarddark text-xs">
            {product.price.toLocaleString('en-US')} ر.س
          </span>

          {outOfStock ? (
            <span className="text-xs font-medium text-inkfaint">غير متوفر</span>
          ) : isOwn ? (
            <span className="text-xs font-medium text-inkfaint">منتجك</span>
          ) : (
            <button
              onClick={onBuy}
              disabled={buying}
              className="text-xs font-bold bg-awning text-white rounded-tag px-3 py-1.5 hover:bg-awningdark active:scale-95 transition disabled:opacity-60"
            >
              {buying ? 'جارٍ...' : 'شراء'}
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
